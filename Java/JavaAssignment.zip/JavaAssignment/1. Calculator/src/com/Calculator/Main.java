package com.Calculator;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        System.out.println("Welcome to the Calculator.");

        System.out.println("1. Perform Arithmetic Operation");
        System.out.println("2. Perform Logical Operation ");
        System.out.println("3. Exit\n");

        Scanner input = new Scanner(System.in);
        int opt = input.nextInt();

        if(opt == 1){
            System.out.print("Enter first number: ");
            int num1 = input.nextInt();
            System.out.print("Enter second number: ");
            int num2 = input.nextInt();

            System.out.print("Choose the arithmetic operation: +, -, *, /, %: ");
            String opr = input.next();

            switch (opr){
                case "+":
                    System.out.println(num1 + num2);
                    break;
                case "-":
                    System.out.println(num1 - num2);
                    break;
                case "*":
                    System.out.println(num1 * num2);
                    break;
                case "/":
                    System.out.println(num1 / num2);
                    break;
                case "%":
                    System.out.println(num1 % num2);
                    break;
                default:
                    System.out.println("Invalid Input.");
            }

        }
        else if(opt == 2){
            System.out.print("Enter first input (true/false): ");
            boolean in1 = input.nextBoolean();
            System.out.print("Enter second input (true/false): ");
            boolean in2 = input.nextBoolean();

            System.out.print("Choose the Logical operation: and, or, not: ");
            String opr = input.next();

            switch (opr){
                case "and":
                    System.out.println(in1 && in2);
                    break;
                case "or":
                    System.out.println(in1 || in2);
                    break;
                case "not":
                    System.out.println(in1 != in2);
                    break;
                default:
                    System.out.println("Invalid Input");
            }

        }
        else if(opt == 3){
            System.exit(0);
        }
    }
}
