package com.MaxMin;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner input = new Scanner(System.in);
        System.out.println("Enter 4 integers one by one-");
        System.out.print("Integer 1: ");
        int a = input.nextInt();
        System.out.print("Integer 2: ");
        int b = input.nextInt();
        System.out.print("Integer 3: ");
        int c = input.nextInt();
        System.out.print("Integer 4: ");
        int d = input.nextInt();

        int max;
        int min;

        if(a > b && a > c && a > d){
            max = a;
            min = ((b < c && b < d) ? b : ((c < d) ? c : d));
            System.out.println("Max is: " + max);
            System.out.println("Min is: " + min);
        }
        else if(b > a && b > c && b > d){
            max = b;
            min = ((a < c && a < d) ? a : ((c < d) ? c : d));
            System.out.println("Max is: " + max);
            System.out.println("Min is: " + min);
        }
        else if(c > b && c > a && c > d){
            max = c;
            min = ((b < a && b < d) ? b : ((a < d) ? a : d));
            System.out.println("Max is: " + max);
            System.out.println("Min is: " + min);
        }
        else if(d > b && d > c && d > a){
            max = d;
            min = ((b < c && b < a) ? b : ((c < a) ? c : a));
            System.out.println("Max is: " + max);
            System.out.println("Min is: " + min);
        }
    }
}
