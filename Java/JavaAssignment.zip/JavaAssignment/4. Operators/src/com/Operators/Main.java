package com.Operators;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.print("10&50 will be: ");
        System.out.println(10&50);

        System.out.print("30||40 will be: ");
        System.out.println(30|40);

        System.out.print("~50 will be: ");
        System.out.println(~50);

        System.out.print("60>>3 will be: ");
        System.out.println(60>>3);

        System.out.print("70<<8 will be: ");
        System.out.println(70<<8);

        System.out.print("55>>>2 will be: ");
        System.out.println(55>>>2);
    }
}
