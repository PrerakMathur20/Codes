package com.Addition;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.print("Enter the number of variables (2-4): ");
        Scanner input = new Scanner(System.in);
        int count = input.nextInt();
        count--;

        if(count == 1){
            System.out.print("Enter first input: ");
            int in1 = input.nextInt();
            System.out.print("Enter second input: ");
            int in2 = input.nextInt();

            new Add(in1, in2);
        }
        else if(count == 2){
            System.out.print("Enter first input: ");
            int in1 = input.nextInt();
            System.out.print("Enter second input: ");
            int in2 = input.nextInt();
            System.out.print("Enter third input: ");
            int in3 = input.nextInt();

            new Add(in1, in2, in3);
        }
        else if(count == 3){
            System.out.print("Enter first input: ");
            int in1 = input.nextInt();
            System.out.print("Enter second input: ");
            int in2 = input.nextInt();
            System.out.print("Enter third input: ");
            int in3 = input.nextInt();
            System.out.print("Enter fourth input: ");
            int in4 = input.nextInt();

            new Add(in1, in2, in3, in4);
        }
    }
}

class Add{
    int sum;

    Add(int in1, int in2){
        System.out.print("The sum is: ");
        System.out.println(in1 + in2);
    }
    Add(int in1, int in2, int in3){
        System.out.print("The sum is: ");
        System.out.println(in1 + in2 + in3);
    }
    Add(int in1, int in2, int in3, int in4){
        System.out.print("The sum is: ");
        System.out.println(in1 + in2 + in3 + in4);
    }
}
