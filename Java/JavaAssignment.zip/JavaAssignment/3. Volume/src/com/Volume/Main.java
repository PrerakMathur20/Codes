package com.Volume;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("1. For Volume");
        System.out.println("2. For Area");
        System.out.print("Your Input: ");
        Scanner input = new Scanner(System.in);
        int opt = input.nextInt();

        if(opt == 1){
            for (int i = 0; i < 3; i++) {
                System.out.println("Enter dimensions for box number: " + (i+1) );
                double in1, in2, in3;
                System.out.print("Length: ");
                in1 = input.nextDouble();
                System.out.print("Width: ");
                in2 = input.nextDouble();
                System.out.print("Depth: ");
                in3 = input.nextDouble();

                new Volume(in1, in2, in3, i);
            }
        }
        else if(opt == 2){
            System.out.println("1. Area of Circle");
            System.out.println("2. Area of Rectangle");
            System.out.print("Your Input: ");
            int in = input.nextInt();

            if(in == 1){
                System.out.print("Enter radius of circle: ");
                double rad = input.nextDouble();

                new Area(rad);
            }
            else if(in == 2){
                System.out.print("Enter length of rectangle: ");
                double len = input.nextDouble();
                System.out.print("Enter width of rectangle: ");
                double wid = input.nextDouble();

                new Area(len, wid);
            }
        }
    }
}

class Volume{
    double vol;
    Volume(double l, double b, double h, int count){
        vol = l*b*h;
        System.out.println("Volume of Box number " + (count + 1) + " is " + vol);
    }
}

class Area{
    double ar;
    Area(double r){
        double pi = 3.14;
        ar = pi * r * r;
        System.out.println("Area of circle with radius " + r + " is: " + ar);
    }
    Area(double l, double w){
        ar = l * w;
        System.out.println("Area of the rectangle will be: " + ar);
    }
}
