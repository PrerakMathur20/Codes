package com.Solve;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int a, b, c, d, e, f, z;
        z = 8;
        
        a = (z++) + (++z);
        b = (z--) + (--z);
        c = z++;
        d = ++z;
        e = z--;
        f = --z;

        System.out.println("Value of a: " + a);
        System.out.println("Value of b: " + b);
        System.out.println("Value of c: " + c);
        System.out.println("Value of d: " + d);
        System.out.println("Value of e: " + e);
        System.out.println("Value of f: " + f);
        System.out.println("Value of z: " + z);

    }
}
